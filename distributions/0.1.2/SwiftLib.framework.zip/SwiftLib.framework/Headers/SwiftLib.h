//
//  SwiftLib.h
//  SwiftLib
//
//  Created by safetrust on 01/07/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for SwiftLib.
FOUNDATION_EXPORT double SwiftLibVersionNumber;

//! Project version string for SwiftLib.
FOUNDATION_EXPORT const unsigned char SwiftLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftLib/PublicHeader.h>


